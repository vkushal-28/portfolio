export const servicesData = [
  {
    id: 1,
    icon_image: null,
    service_name: "Web Development",
    shadow_icon: "fa-solid fa-code",
    service_description: "Web development description 1",
  },
  {
    id: 1,
    icon_image: null,
    service_name: "API Integration",
    shadow_icon: "fa-solid fa-screwdriver-wrench",
    service_description: "Web development description 1",
  },
  {
    id: 1,
    icon_image: null,
    service_name: "Restful API Development",
    shadow_icon: "fa-solid fa-gear",
    service_description: "Web development description 1",
  },
];
